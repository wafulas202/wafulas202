#ifndef COMMON_H
#define COMMON_H

#ifdef _WIN32
#define CLEAR "cls"
#else
// Assume Unix system
#define CLEAR "clear"
#endif

#endif /* COMMON_H */
