#include "search.h"

Search::Search() {}
Search::~Search() {}
