#include "ai_player.h"

AIPlayer::AIPlayer() {}
AIPlayer::~AIPlayer() {}

const string &AIPlayer::get_player_string_move() {
  return empty_str;
}
