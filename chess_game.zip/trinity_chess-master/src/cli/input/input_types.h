#ifndef INPUT_TYPE_H
#define INPUT_TYPE_H
#pragma once

enum class InputType {
  Keyboard = 0,
  Text = 1,
};

#endif /* INPUT_TYPE_H */
