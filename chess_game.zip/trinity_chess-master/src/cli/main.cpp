#include "game/game.h"

int main(/*int argc, char *argv[]*/) {
  Game game;
  game.start();
  return EXIT_SUCCESS;
}
